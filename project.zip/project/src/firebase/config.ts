export const firebaseConfig = {
  "projectId": "studio-217719458-e04da",
  "appId": "1:191923259066:web:ecab4ebe61e2bce5d8e483",
  "apiKey": "AIzaSyBgyBX9UuA_5QQreoKkseEcn-uyBzmuR9E",
  "authDomain": "studio-217719458-e04da.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "191923259066"
};
