
import { MetadataRoute } from 'next'

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: 'WebNexus App Shell',
    short_name: 'WebNexus',
    description: 'מערכת מעטפת חכמה לאפליקציות ומשחקים',
    start_url: '/',
    display: 'standalone',
    background_color: '#121212',
    theme_color: '#8B5CF6',
    icons: [
      {
        src: 'https://picsum.photos/seed/appicon/192/192',
        sizes: '192x192',
        type: 'image/png',
      },
      {
        src: 'https://picsum.photos/seed/appicon/512/512',
        sizes: '512x512',
        type: 'image/png',
      },
    ],
  }
}
